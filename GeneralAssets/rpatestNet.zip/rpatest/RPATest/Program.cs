﻿using System;
using System.Diagnostics;

namespace RPATest
{
    class Program
    {
        static string  AddArgument(string arguments)
        {
 
            return arguments;
        }
        static void Main()
        {
            //LaunchCommandLineApp();
            
            string const_file1 = " -file ";
            string robot_path = "\"C:\\Users\\carlos.rendon\\Documents\\UiPath\\DemoNoMessages\\";
            string robot_name = "Main.xaml\"";
            
            string const_file2 = "  -input \"{\'UserName' : '";
            string user_name = "condor/leo.rendon";
            string const_file3 = "' , 'Password' : '";
            string password = "sofia";
            string const_file4 = "' , 'ConnectionStringRobot' : '";
            string connection_stringRobot = "Data Source = 192.168.1.246; Initial Catalog = RPA_Condor; User ID = carlos.rendon; Password = CarRen2020*";
            string const_file5 = "' , 'sp_start_trace' : '";
            string sp_start_trace = "PutTesting_Trace_Started";
            string const_file6 = "' , 'client_robot_name' : '";
            string client_robot_name = "Testing Robot 1501 Carlos Rendon";
            string const_file7 = "' , 'ConnectionStringClient' : '";
            string connection_stringClient = "Data Source = 192.168.1.246; Initial Catalog = Adv_Condor_Pruebas; User ID = carlos.rendon; Password = CarRen2020*";
            string const_file8 = "' , 'sp_end_trace' : '";
            string sp_end_trace = "PutTesting_Trace_Ended";
            string const_file9 = "' , 'sp_load_information' : '";
            string sp_load_information = "Get_Testing_Information";
            string const_file10 = "'}\"";
            string arguments;

            //arguments = const_file1 + robot_path + robot_name + const_file2 + user_name +
            //            const_file3 + password + const_file8;

            arguments = const_file1 + robot_path + robot_name + const_file2 + user_name +
                const_file3 + password + const_file4 + connection_stringRobot +
                const_file5 + sp_start_trace + const_file6 +
                client_robot_name + const_file7 + connection_stringClient + const_file8 +
                sp_end_trace + const_file9 +
                sp_load_information + const_file10;


            LaunchRobot(arguments);
        }

        static void LaunchRobot(string arguments)
        {
            string UiRobot_path = "C:\\Users\\carlos.rendon\\AppData\\Local\\UiPath\\app-20.4.0-beta1731\\";
            string UiRobot = "UiRobot.exe";
            string UiRobotFileName = UiRobot_path + UiRobot;
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = UiRobotFileName;
            startInfo.Arguments = arguments;
            Process.Start(startInfo);
        }

        //static void LaunchCommandLineApp()
        //{
        //    string UirRbot_path = "C:\\Users\\carlos.rendon\\AppData\\Local\\UiPath\\app-20.4.0-beta1731\\";
        //    string UiRobot = "UiRobot.exe";
        //    string const_file = " -file ";
        //    string robot_path = "C:\\Users\\carlos.rendon\\Documents\\UiPath\\Demo\\";
        //    string robot_path = "C:\\Users\\carlos.rendon\\Documents\\UiPath\\Demo\\";

        //    // Part 1: use ProcessStartInfo class.
        //    ProcessStartInfo startInfo = new ProcessStartInfo();
        //    startInfo.CreateNoWindow = false;
        //    startInfo.UseShellExecute = false;
        //    startInfo.FileName = "dcm2jpg.exe";
        //    startInfo.WindowStyle = ProcessWindowStyle.Hidden;

        //    // Part 2: set arguments.
        //    startInfo.Arguments = "-f j -o \"" + ex1 + "\" -z 1.0 -s y " + ex2;

        //    try
        //    {
        //        // Part 3: start with the info we specified.
        //        // ... Call WaitForExit.
        //        using (Process exeProcess = Process.Start(startInfo))
        //        {
        //            exeProcess.WaitForExit();
        //        }
        //    }
        //    catch
        //    {
        //        // Log error.
        //    }
        //}
    }
}
