select * from tur_periodos
where cerrado_liquidacion = 0 
and year(desde) = 2020